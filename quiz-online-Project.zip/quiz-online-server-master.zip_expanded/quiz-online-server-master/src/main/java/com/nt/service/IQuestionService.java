package com.nt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.crossstore.ChangeSetPersister;

import com.nt.model.Question;

/**
 * Service interface for managing quiz questions.
 * Defines methods for creating, retrieving, updating, deleting, and fetching quiz questions.
 * 
 * @author Simpson Alfred
 */
public interface IQuestionService {

    /**
     * Creates a new question.
     *
     * @param question the question to create.
     * @return the created question.
     */
    Question createQuestion(Question question);

    /**
     * Retrieves all questions.
     *
     * @return a list of all questions.
     */
    List<Question> getAllQuestions();

    /**
     * Retrieves a question by its ID.
     *
     * @param id the ID of the question.
     * @return an optional containing the question if found, or empty if not found.
     */
    Optional<Question> getQuestionById(Long id);

    /**
     * Retrieves a list of all distinct subjects from the questions.
     *
     * @return a list of distinct subjects.
     */
    List<String> getAllSubjects();

    /**
     * Updates an existing question.
     *
     * @param id the ID of the question to update.
     * @param question the updated question details.
     * @return the updated question.
     * @throws ChangeSetPersister.NotFoundException if the question is not found.
     */
    Question updateQuestion(Long id, Question question) throws ChangeSetPersister.NotFoundException;

    /**
     * Deletes a question by its ID.
     *
     * @param id the ID of the question to delete.
     */
    void deleteQuestion(Long id);

    /**
     * Retrieves a specified number of random questions for a given subject.
     *
     * @param numOfQuestions the number of questions to retrieve.
     * @param subject the subject to filter questions by.
     * @return a list of questions for the given subject.
     */
    List<Question> getQuestionsForUser(Integer numOfQuestions, String subject);
}}
