package com.nt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.crossstore.ChangeSetPersister;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.nt.model.Question;
import com.nt.repository.QuestionRepository;

import lombok.RequiredArgsConstructor;

/**
 * Service implementation for managing quiz questions.
 * Handles the business logic for CRUD operations and quiz-related functionalities.
 * 
 * @author Simpson Alfred
 */
@Service
@RequiredArgsConstructor
public class QuestionService implements IQuestionService {
    private final QuestionRepository questionRepository;

    /**
     * Creates a new question and saves it to the repository.
     * 
     * @param question the question to create.
     * @return the saved question.
     */
    @Override
    public Question createQuestion(Question question) {
        return questionRepository.save(question);
    }

    /**
     * Retrieves all questions from the repository.
     * 
     * @return a list of all questions.
     */
    @Override
    public List<Question> getAllQuestions() {
        return questionRepository.findAll();
    }

    /**
     * Retrieves a question by its ID.
     * 
     * @param id the ID of the question to retrieve.
     * @return an Optional containing the question if found, or empty if not found.
     */
    @Override
    public Optional<Question> getQuestionById(Long id) {
        return questionRepository.findById(id);
    }

    /**
     * Retrieves a list of all distinct subjects in the repository.
     * 
     * @return a list of distinct subjects.
     */
    @Override
    public List<String> getAllSubjects() {
        return questionRepository.findDistinctSubject();
    }

    /**
     * Updates an existing question by its ID.
     * 
     * @param id the ID of the question to update.
     * @param question the updated question details.
     * @return the updated question.
     * @throws ChangeSetPersister.NotFoundException if the question is not found.
     */
    @Override
    public Question updateQuestion(Long id, Question question) throws ChangeSetPersister.NotFoundException {
        Optional<Question> existingQuestion = this.getQuestionById(id);
        if (existingQuestion.isPresent()) {
            Question updatedQuestion = existingQuestion.get();
            updatedQuestion.setQuestion(question.getQuestion());
            updatedQuestion.setChoices(question.getChoices());
            updatedQuestion.setCorrectAnswers(question.getCorrectAnswers());
            updatedQuestion.setSubject(question.getSubject());
            updatedQuestion.setQuestionType(question.getQuestionType());
            return questionRepository.save(updatedQuestion);
        } else {
            throw new ChangeSetPersister.NotFoundException();
        }
    }

    /**
     * Deletes a question by its ID.
     * 
     * @param id the ID of the question to delete.
     */
    @Override
    public void deleteQuestion(Long id) {
        questionRepository.deleteById(id);
    }

    /**
     * Retrieves a specified number of questions for a given subject.
     * 
     * @param numOfQuestions the number of questions to retrieve.
     * @param subject the subject to filter questions by.
     * @return a list of questions for the given subject, limited to the specified number.
     */
    @Override
    public List<Question> getQuestionsForUser(Integer numOfQuestions, String subject) {
        Pageable pageable = PageRequest.of(0, numOfQuestions);
        return questionRepository.findBySubject(subject, pageable).getContent();
    }
}
