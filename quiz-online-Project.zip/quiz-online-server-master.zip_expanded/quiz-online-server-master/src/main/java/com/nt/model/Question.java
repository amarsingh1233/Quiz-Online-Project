package com.nt.model;

import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import lombok.Getter;
import lombok.Setter;

/**
 * Entity representing a quiz question.
 * Includes fields for question text, subject, type, choices, and correct answers.
 * 
 * @author Simpson Alfred
 */
@Getter
@Setter
@Entity
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Question text cannot be blank.")
    private String question;

    @NotBlank(message = "Subject cannot be blank.")
    private String subject;

    @NotBlank(message = "Question type cannot be blank.")
    private String questionType;

    @ElementCollection
    private List<@NotBlank(message = "Choice cannot be blank.") String> choices;

    @ElementCollection
    private List<@NotBlank(message = "Correct answer cannot be blank.") String> correctAnswers;
}
