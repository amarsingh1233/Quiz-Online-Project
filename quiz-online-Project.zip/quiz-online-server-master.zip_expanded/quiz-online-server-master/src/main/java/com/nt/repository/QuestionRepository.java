package com.nt.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nt.model.Question;

/**
 * Repository interface for managing `Question` entities.
 * Provides custom query methods to retrieve distinct subjects and paginate questions by subject.
 * 
 * @author Simpson Alfred
 */
public interface QuestionRepository extends JpaRepository<Question, Long> {

    /**
     * Retrieves a list of distinct subjects from the question database.
     *
     * @return List of distinct subjects.
     */
    @Query("SELECT DISTINCT q.subject FROM Question q")
    List<String> findDistinctSubjects();

    /**
     * Retrieves a paginated list of questions filtered by subject.
     *
     * @param subject the subject to filter questions by.
     * @param pageable the pagination information.
     * @return a paginated list of questions.
     */
    Page<Question> findBySubject(String subject, Pageable pageable);
}
